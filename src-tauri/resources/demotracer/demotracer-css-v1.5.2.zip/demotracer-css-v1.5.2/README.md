# DemoTracer-CSS v1.5.2

This is the complete Windows x64 local playback package. Install it into the CS2
server used for replay; it is not a hosted or cloud service. The bundle includes
the Metamod dtr-controller and dtr-hider runtimes plus their CounterStrikeSharp
plugins as one matching runtime set.

## Install

1. Stop the CS2 server.
2. Install Metamod:Source build 1469+ (plugin API 18)
   and the KHook-enabled CounterStrikeSharp source baseline listed below.
   They are prerequisites and are not included in this bundle.
3. Use the GUI installer to migrate receipt-owned legacy DTR files. It preserves
   independently installed upstream components and user data. For a manual upgrade,
   remove only the old DTR-owned native VDF/DLL and managed provider/API files,
   then copy user bot_info.json, map_whitelist.json and recordings to the new paths.
4. Keep this bundle's `dtr-controller`, `dtr-hider` and shared APIs together.
5. Copy this package's `addons` directory into the server `game/csgo` directory
   so it merges with the existing `addons` directory.
6. Start the server.
7. In the server console, run:

```text
dtr_runtime
dtr_controller_status
dtr_hider_status
```

Expected ABI check:

```text
expected_abi=22 runtime_abi=22 abi_minor=1
```

For v1.5.2, require `runtime_abi=22` and `abi_minor=1` or newer. If the minor
version is missing or lower, replace the complete playback bundle, including
`addons/dtr-controller/bin/win64/dtr-controller.dll`,
`addons/dtr-controller/gamedata.json`, and `addons/metamod/dtr-controller.vdf`.

## Desktop Playback Presets

The desktop GUI generates a compact command such as:

```text
dtr_preset 0x15; dtr_go seq "<manifest.json>" 0
```

`dtr_preset status` prints the effective v1 mask and bit assignments. Presets
from the current desktop GUI require a playback bundle that includes this
command.

## Voice Replay

Voice playback uses demo-backed `.dtv` sidecars exported by the desktop GUI when
voice export is enabled. Keep `voice/roundXX.dtv` next to the matching manifest
output and enable `dtr_voice_auto on` before `dtr_go seq` or `dtr_go round`.

## Chat Replay

Text chat is stored in `manifest.json` as `rounds[].chat_messages` and replays
through CS2's native `say` / `say_team` path when `dtr_chat_auto on` is enabled
(default). For spectator testing of native player text chat, set
`sv_full_alltalk 1`; `sv_allchat 1` by itself is not enough.

## Contents

- `addons/dtr-controller/bin/win64/dtr-controller.dll`
- `addons/dtr-controller/gamedata.json`
- `addons/metamod/dtr-controller.vdf`
- `addons/dtr-hider/bin/win64/dtr-hider.dll`
- `addons/dtr-hider/gamedata.json`
- `addons/dtr-hider/bot_info.example.json` (does not overwrite local `bot_info.json`)
- `addons/demotracer-install.v1.json` (component contract and file hashes for desktop diagnostics)
- `addons/counterstrikesharp/plugins/DtrHider/`
- `addons/counterstrikesharp/shared/DtrHiderApi/`
- `addons/counterstrikesharp/shared/BotRandomizerApi/`
- `addons/counterstrikesharp/plugins/BotRandomizer/`
  - `cosmetic_catalog.json` random-roll pools
  - `cs2-lib-econ-index.v1.json` canonical replay-evidence allow-list
- `addons/counterstrikesharp/shared/DemoTracerApi/`
- `addons/counterstrikesharp/plugins/DemoTracer/`
  - `demotracer.config.example.json` sanitized local runtime defaults
  - `cs2-lib-econ-index.v1.json` compact projection of the pinned cs2-lib catalog
  - `demotracer-runtime.v1.json` is created at runtime as a short-lived local
    health heartbeat; it is not prepackaged

## Compatibility

Native dtr-hider loads on the first replay command, after unloading official
BotHider and BotHiderImpl when present. It owns the rest of that map; changing
maps restores the original providers. Do not add a dtr-hider startup VDF.

- Required BotController native ABI: 22
- Required BotController native ABI minor: 1 or newer
- Supported `.dtr` format: 12 only; reconvert older archives with the current GUI.
- DemoTracer companion API: 7
- DemoTracer BotHider API: 3
- BotRandomizer replay-plan API: 3
- CounterStrikeSharp plugin target: net10.0
- Maintained runtime platform: Windows x64

## Dependencies

Required external server prerequisites:

- Metamod:Source 2.0 build 1469 or newer (plugin API 18, KHook).
- CounterStrikeSharp with the KHook backend. The matched baseline is PR #1418,
  source commit `9cbdee0ce7871671f38ff25101052bd5c2f0a858`. A managed API version number alone does
  not prove KHook support; stock v1.0.374 and older use the previous backend.
- Native source pins: Metamod `fa6f80e4662e5b96cc2e97722d812f374581dfd8`, KHook `40d233d160b5bf60cc3e732939142b222fbd8ece`.

Included in this bundle:

- `dtr-controller` Metamod runtime
- `dtr-hider` Metamod runtime maintained by DemoTracer
- `DemoTracer` CounterStrikeSharp plugin
- `dtr-hider` CounterStrikeSharp plugin
- `BotRandomizer` CounterStrikeSharp replay-cosmetic provider
- `DtrHiderApi.dll`
- `BotRandomizerApi.dll`
- `DemoTracerApi.dll`
- `cs2-lib-econ-index.v1.json`
- `demotracer.config.example.json`

DTR DLLs, API capabilities, commands and installation paths are isolated from
upstream components. KHook coordinates shared detours; it does not arbitrate
competing gameplay or presentation writes to the same bots.

Do not infer BotController/BotHider compatibility from directory names or VDF
targets. Known CS2-Bot-Improver v1.4.2 native packages use BotController ABI 14;
DemoTracer requires ABI 22/minor 1. The desktop environment inspection reads
`addons/demotracer-install.v1.json` and exact component hashes to detect a mixed
or replaced vendor set.

Contact handoff uses the bundled BotController native perception. No external
tracing provider is required.

The bundled common BotRandomizer API v3 provider is the sole cosmetic entity writer.
DemoTracer submits validated demo evidence as a complete desired-state plan
before the next natural spawn; BotRandomizer consumes it during GiveNamedItem
construction. Replay validation uses the canonical cs2-lib econ index rather
than the narrower random-roll pools. DemoTracer does not mutate weapon econ
state, knife subclasses, gloves, agent models, or music-kit fields directly.
